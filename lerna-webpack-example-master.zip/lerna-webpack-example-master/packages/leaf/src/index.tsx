import React from 'react';

const Leaf = () => <div>Sync leaf!</div>;

export default Leaf;
