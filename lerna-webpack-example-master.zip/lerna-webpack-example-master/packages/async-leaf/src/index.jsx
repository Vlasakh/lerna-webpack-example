import React from 'react';

const AsyncLeaf = () => (<div>AsyncLeaf Loaded!</div>);

export default AsyncLeaf;
